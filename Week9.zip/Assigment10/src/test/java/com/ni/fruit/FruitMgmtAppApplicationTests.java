package com.ni.fruit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitMgmtAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
