package com.ni.fruit;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.*;

@RestController
@RequestMapping("/api/fruit")
public class FruitRestController {

    // Listing all farmers from the repositry
    @GetMapping("/list/{type}")
    public List<Fruit> listFruits() {
        return FruitRepositry.fruitsList;
    }


    @GetMapping(value = "/v2/{name}")
    public ResponseEntity<Fruit> listFarmers_V2(@PathVariable int id) {
        //Create and set our own custom http headers
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set("Company-name", "Nich");
        responseHeaders.set("Company-year", "2465");
        responseHeaders.set("Fruit-API-Version", "2.1");

        //The farmer that we want to sent
        Fruit resultFarmer = FruitRepositry.fruitsList.size() > 0 ? FruitRepositry.fruitsList.get(id - 1) : null;

        return new ResponseEntity<Fruit>(
            resultFarmer,
            responseHeaders,
            resultFarmer!=null ? HttpStatus.FOUND : HttpStatus.NOT_FOUND
            );
    }

}
