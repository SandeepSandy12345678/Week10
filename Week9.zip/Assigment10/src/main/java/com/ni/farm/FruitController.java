package com.ni.farm;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping("fruit")
public class FruitController {

    //Example URL: "localhost:8080/farmer/id/1/age/100"
    @GetMapping("/name/{name}/color/{color}")
    @ResponseBody
    public String abc1(@PathVariable String name, @PathVariable String color,String type) {

        return name + "Fruit  " + " and color is " + color+"type is"+type;
    }

    // Listing all farmers from the repositry
    @GetMapping("/list/{type}")
    @ResponseBody
    public List<Fruit> listFarmers() {
        return FruitRepositry.fruitsList;
    }

    // Listing all farmers from the repositry, using Thymeleaf templates
    @GetMapping("/list-v2")
    public String listFarmersV2(Model model) {
        model.addAttribute("fruitList", FruitRepositry.fruitsList);

        return "fruit-list.html";
    }

    // HTML form processing
    // form input values are captured as the method arguments when they have same
    // name
    @PostMapping("/addnewfruit")
    @ResponseBody
    public RedirectView addNewFarmer(String fruitName, String fruitColor, String type) {
        FruitRepositry.fruitsList.add(new Fruit(fruitName, fruitColor, type));
        int fruitCount = FruitRepositry.fruitsList.size();

        // String response = String.format("Recieved a new farmer (%s %s %s). Thank you, your are farmer no %s",
        //         farmerName, farmerAge, farmerExperience, farmerCount);
        // return response;

        RedirectView redirectView = new RedirectView("/farmer/list-v2"); 
        return redirectView;

 
    }


    @PostMapping("/deletefruit")
    @ResponseBody
    public RedirectView DeleteFarmer(String fruitName, String fruitColor,String type) {
        FruitRepositry.fruitsList = FruitRepositry.fruitsList
                .stream()
                .filter( fruit -> !(fruit.name.equals(fruitName) && fruit.color.equals(fruitColor) && fruit.type.equals(type)))
                .collect(Collectors.toList());

        int fruitCount = FruitRepositry.fruitsList.size();

        // String response = String.format("Deleted farmer  (%s). Farmer list count- %s",
        //         farmerName, farmerCount);
        // return response;

        // return "redirect:list-v2";
        //44B Solved
        RedirectView redirectView = new RedirectView("/fruit/list-v2"); 
        return redirectView;
    }

    //44B
    // Enhance addnewfarmer and deletefarmer 
    // such that they return the user to farmer listing
}
