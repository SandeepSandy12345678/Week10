package com.ni.farm;

import java.util.ArrayList;
import java.util.List;

public class FruitRepositry {
    public static List<Fruit> fruitsList = new ArrayList<>();
    
}
